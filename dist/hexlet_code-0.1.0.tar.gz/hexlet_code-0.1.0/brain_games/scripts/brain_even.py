#!/usr/bin/env python3
from brain_games.pairty import even

def main():
    even()

if __name__ == "__main__":
    main()



