#!/usr/bin/env python3
from brain_games.games.parity import generate_question
from brain_games.engine import play_game
from brain_games.consts import PARITY_RULE


def main():
    play_game(PARITY_RULE, generate_question)


if __name__ == "__main__":
    main()
