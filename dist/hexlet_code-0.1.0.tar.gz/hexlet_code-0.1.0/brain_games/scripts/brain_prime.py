#! /usr/bin/env python3
from brain_games.prime import prime_games


def main():
    prime_games


if __name__ == "__main__":
    main()
