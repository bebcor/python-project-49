NUMBER_OF_ROUNDS = 3
PROGRESSION_RULE = "What number is missing in the progression?"
PRIME_RULE = 'Answer "yes" if given number is prime. Otherwise answer "no".'
PARITY_RULE = 'Answer "yes" if the number is even, otherwise answer "no".'
GCD_RULE = "Find the greatest common divisor of given numbers."
CALCULATOR_RULE = "What is the result of the expression?"
