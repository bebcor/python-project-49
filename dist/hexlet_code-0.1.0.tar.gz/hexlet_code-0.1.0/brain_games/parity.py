import random
import prompt


def even():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print(f"Hello, {name}!")
    x = 0
    print('Answer "yes" if the number is even, otherwise answer "no"')
    while x != 3:
        random_number = random.randint(0,10)
        print(f"Question: {random_number}")
        y = input("Your answer:")
        if y == "yes" and random_number%2 == 0:
            print("correct")
            x += 1
        elif y == "no" and random_number%2 != 0:
            print("correct")
            x += 1
        else:
            print(f"'{y}' is wrong answer ;(. Correct answer was 'no'\nLet's try again, {name}")
            x = 0
    print(f"Congratulations, {name}")

