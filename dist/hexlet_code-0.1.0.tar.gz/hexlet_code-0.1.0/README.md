### Hexlet tests and linter status:
[![Actions Status](https://github.com/bebcor/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bebcor/python-project-49/actions)
<a href="https://codeclimate.com/github/bebcor/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/99d1b9997b0fdebf4996/maintainability" /></a>
