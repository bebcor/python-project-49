#!/usr/bin/env python3
from brain_games.progression import progression_games


def main():
    progression_games


if __name__ == "__main__":
    main()
