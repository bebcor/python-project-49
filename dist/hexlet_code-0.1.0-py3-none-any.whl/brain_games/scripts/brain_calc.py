#!/usr/bin/env python3
from brain_games.calculator import calculator_games


def main():
    calculator_games


if __name__ == "__main__":
    main()
