from brain_games.GCD import GCD_games


def main():
    GCD_games


if __name__ == "__main__":
    main()
