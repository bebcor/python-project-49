import random


def generate_number(min_val: int = 1, max_val: int = 100):
    return random.randint(min_val, max_val)
